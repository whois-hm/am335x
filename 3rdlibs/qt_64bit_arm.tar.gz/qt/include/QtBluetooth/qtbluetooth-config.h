#define QT_FEATURE_bluez -1
