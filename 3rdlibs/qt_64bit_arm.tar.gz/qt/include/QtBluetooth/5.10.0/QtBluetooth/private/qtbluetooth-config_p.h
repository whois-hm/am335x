#define QT_FEATURE_bluez_le -1
#define QT_FEATURE_linux_crypto_api -1
#define QT_FEATURE_winrt_bt -1
