#ifndef DEPRECATED_HEADER_QtBluetooth_qbluetoothglobal_h
#define DEPRECATED_HEADER_QtBluetooth_qbluetoothglobal_h
#if defined(__GNUC__)
#  warning Header <QtBluetooth/qbluetoothglobal.h> is deprecated. Please include <QtBluetooth/qtbluetoothglobal.h> instead.
#elif defined(_MSC_VER)
#  pragma message ("Header <QtBluetooth/qbluetoothglobal.h> is deprecated. Please include <QtBluetooth/qtbluetoothglobal.h> instead.")
#endif
#include <QtBluetooth/qtbluetoothglobal.h>
#if 0
#pragma qt_no_master_include
#endif
#endif
