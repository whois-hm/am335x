#!/bin/sh
if [ $# -eq 1 ];then
	export TSDIR=$1
	export LD_LIBRARY_PATH=${TSDIR}/lib:${LD_LIBRARY_PATH}
	export TSLIB_TSDEVICE=/dev/input/event1
	export TSLIB_PLUGINDIR=${TSDIR}/lib/ts/
	export TSLIB_CALIBFILE=${TSDIR}/etc/pointercal
	export TSLIB_FBDEVICE=/dev/fb0
	export TSLIB_CONFFILE=${TSDIR}/etc/ts.conf

else
	echo "can't export tslib, parameter is none"
fi
